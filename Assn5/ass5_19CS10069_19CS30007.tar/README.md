# Assignment 5

## Instructions:

For compiling and running the code, use command: `make`.

For performing a clean use: `make clean`

The inputs will be taken from the files in the `input/` folder.

The outputs will be stored in the `output/` folder.
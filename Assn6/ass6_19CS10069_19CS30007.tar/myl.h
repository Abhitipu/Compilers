#ifndef _MYL_H			// Header file myl.h
#define _MYL_H
#define ERR 0			// defining OK and ERR for testing
#define OK 1
int printStr(char *);		// function declarations
int printInt(int);
int readInt(int *);
#endif
